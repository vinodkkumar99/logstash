# Security Policy

## Reporting a Vulnerability

For security vulnerabilities please only send reports to security@elastic.co.
See https://www.elastic.co/community/security for more information.
