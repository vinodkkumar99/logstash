---
name: Test Failure
about: A test failure in CI
labels: "test failure"

---

<!--
Please fill out the following information, and ensure you have attempted
to reproduce locally
-->

**Build scan**:

**Repro line**:

**Reproduces locally?**:

**Applicable branches**:

**Failure history**:
<!--
Link to build stats and possible indication of when this started failing and how often it fails
<https://build-stats.elastic.co/app/kibana>
-->
**Failure excerpt**:
