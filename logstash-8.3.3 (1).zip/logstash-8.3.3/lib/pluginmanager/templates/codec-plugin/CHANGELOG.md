## 0.1.0
  - Plugin created with the logstash plugin generator
